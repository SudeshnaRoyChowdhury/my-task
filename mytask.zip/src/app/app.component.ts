import { Component } from '@angular/core';
import { User } from './Model/User';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  public userModel = new User('','','','','',false);

  public userInfo:any =[];
  
  onSubmit(){
  this.userInfo={
    'nm':this.userModel.name,
    'age':this.userModel.age,
    'ph':this.userModel.ph,
    'gen':this.userModel.gen,
    'city':this.userModel.city,
    'isAgree':this.userModel.isAgree
  };

  console.log(this.userInfo);
}
}
