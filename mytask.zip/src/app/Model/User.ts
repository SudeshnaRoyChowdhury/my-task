export class User{
  
    constructor(
        public name:string,
        public age :any,
        public ph :any,
        public gen:string,
        public city:string,
        public isAgree:boolean
    ){

    }
}